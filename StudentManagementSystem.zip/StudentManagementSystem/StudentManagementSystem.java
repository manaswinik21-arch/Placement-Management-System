import java.io.*;
import java.util.*;

public class StudentManagementSystem {

    // ---------------------------------------------------------------
    // Model class
    // ---------------------------------------------------------------
    static class Student {
        private final int id;
        private String name;
        private String department;
        private int year;
        private double mathsMarks;
        private double javaMarks;
        private double dbMarks;

        Student(int id, String name, String department, int year,
                double mathsMarks, double javaMarks, double dbMarks) {
            this.id = id;
            this.name = name;
            this.department = department;
            this.year = year;
            this.mathsMarks = mathsMarks;
            this.javaMarks = javaMarks;
            this.dbMarks = dbMarks;
        }

        int getId() { return id; }
        String getName() { return name; }
        String getDepartment() { return department; }
        int getYear() { return year; }
        double getMaths() { return mathsMarks; }
        double getJava() { return javaMarks; }
        double getDb() { return dbMarks; }

        void setName(String name) { this.name = name; }
        void setDepartment(String department) { this.department = department; }
        void setYear(int year) { this.year = year; }
        void setMaths(double marks) { this.mathsMarks = marks; }
        void setJava(double marks) { this.javaMarks = marks; }
        void setDb(double marks) { this.dbMarks = marks; }

        double getAverage() {
            return (mathsMarks + javaMarks + dbMarks) / 3.0;
        }

        String getGrade() {
            double avg = getAverage();
            if (avg >= 90) return "A+";
            if (avg >= 80) return "A";
            if (avg >= 70) return "B";
            if (avg >= 60) return "C";
            if (avg >= 50) return "D";
            return "F";
        }

        String toFileLine() {
            return id + "|" + name + "|" + department + "|" + year + "|"
                    + mathsMarks + "|" + javaMarks + "|" + dbMarks;
        }

        static Student fromFileLine(String line) {
            String[] p = line.split("\\|", -1);
            if (p.length != 7) return null;
            try {
                return new Student(Integer.parseInt(p[0]), p[1], p[2],
                        Integer.parseInt(p[3]), Double.parseDouble(p[4]),
                        Double.parseDouble(p[5]), Double.parseDouble(p[6]));
            } catch (NumberFormatException ex) {
                return null;
            }
        }
    }

    // ---------------------------------------------------------------
    // Data members
    // ---------------------------------------------------------------
    private static final String DATA_DIR = "data";
    private static final String DATA_FILE = "data/students.txt";
    private static final Scanner in = new Scanner(System.in);
    private static final List<Student> students = new ArrayList<>();

    // ---------------------------------------------------------------
    // Program entry point
    // ---------------------------------------------------------------
    public static void main(String[] args) {
        loadStudents();
        int choice;
        do {
            printMenu();
            choice = readInt("Enter your choice: ", 0, 6);
            switch (choice) {
                case 1: addStudent(); break;
                case 2: viewStudents(); break;
                case 3: searchStudent(); break;
                case 4: updateStudent(); break;
                case 5: deleteStudent(); break;
                case 6: showReport(); break;
                case 0:
                    System.out.println("Thank you for using the "
                            + "Student Management System.");
                    break;
            }
        } while (choice != 0);
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("========== STUDENT MANAGEMENT SYSTEM ==========");
        System.out.println(" 1. Add Student");
        System.out.println(" 2. View All Students");
        System.out.println(" 3. Search Student");
        System.out.println(" 4. Update Student");
        System.out.println(" 5. Delete Student");
        System.out.println(" 6. Performance Report");
        System.out.println(" 0. Exit");
        System.out.println("===============================================");
    }

    // ---------------------------------------------------------------
    // File handling
    // ---------------------------------------------------------------
    private static void loadStudents() {
        File file = new File(DATA_FILE);
        if (!file.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                Student s = Student.fromFileLine(line);
                if (s != null) students.add(s);
            }
        } catch (IOException ex) {
            System.out.println("Could not read data file: " + ex.getMessage());
        }
    }

    private static void saveStudents() {
        new File(DATA_DIR).mkdirs();
        try (PrintWriter out = new PrintWriter(new FileWriter(DATA_FILE))) {
            for (Student s : students) {
                out.println(s.toFileLine());
            }
        } catch (IOException ex) {
            System.out.println("Could not save data file: " + ex.getMessage());
        }
    }

    // ---------------------------------------------------------------
    // Input helpers with validation
    // ---------------------------------------------------------------
    private static int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String line = in.nextLine().trim();
            try {
                int value = Integer.parseInt(line);
                if (value >= min && value <= max) return value;
            } catch (NumberFormatException ignored) { }
            System.out.println("Invalid input. Enter a number between "
                    + min + " and " + max + ".");
        }
    }

    private static double readMarks(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = in.nextLine().trim();
            try {
                double value = Double.parseDouble(line);
                if (value >= 0 && value <= 100) return value;
            } catch (NumberFormatException ignored) { }
            System.out.println("Invalid marks. Enter a value from 0 to 100.");
        }
    }

    private static String readText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = in.nextLine().trim();
            if (!line.isEmpty() && !line.contains("|")) return line;
            System.out.println("Field cannot be empty or contain the | character.");
        }
    }

    private static Student findById(int id) {
        for (Student s : students) {
            if (s.getId() == id) return s;
        }
        return null;
    }

    private static int nextId() {
        int max = 0;
        for (Student s : students) {
            if (s.getId() > max) max = s.getId();
        }
        return max + 1;
    }

    // ---------------------------------------------------------------
    // Table printing
    // ---------------------------------------------------------------
    private static void printHeader() {
        System.out.println("---------------------------------------------------"
                + "-------------------------");
        System.out.printf("%-4s %-16s %-6s %-4s %6s %6s %6s %7s %-5s%n",
                "ID", "Name", "Dept", "Year", "Maths", "Java", "DBMS", "Avg", "Grade");
        System.out.println("---------------------------------------------------"
                + "-------------------------");
    }

    private static void printRow(Student s) {
        System.out.printf("%-4d %-16s %-6s %-4d %6.1f %6.1f %6.1f %7.2f %-5s%n",
                s.getId(), s.getName(), s.getDepartment(), s.getYear(),
                s.getMaths(), s.getJava(), s.getDb(), s.getAverage(), s.getGrade());
    }

    // ---------------------------------------------------------------
    // 1. Add student
    // ---------------------------------------------------------------
    private static void addStudent() {
        System.out.println();
        System.out.println("--- Add New Student ---");
        String name = readText("Name: ");
        String department = readText("Department: ").toUpperCase();
        int year = readInt("Year of study (1-4): ", 1, 4);
        double maths = readMarks("Maths marks (0-100): ");
        double java = readMarks("Java marks (0-100): ");
        double db = readMarks("DBMS marks (0-100): ");
        Student s = new Student(nextId(), name, department, year, maths, java, db);
        students.add(s);
        saveStudents();
        System.out.println("Student added successfully! ID = " + s.getId());
    }

    // ---------------------------------------------------------------
    // 2. View all students
    // ---------------------------------------------------------------
    private static void viewStudents() {
        System.out.println();
        if (students.isEmpty()) {
            System.out.println("No student records found.");
            return;
        }
        System.out.println("--- All Students ---");
        printHeader();
        for (Student s : students) {
            printRow(s);
        }
        System.out.println("Total students: " + students.size());
    }

    // ---------------------------------------------------------------
    // 3. Search student (by ID, name or department)
    // ---------------------------------------------------------------
    private static void searchStudent() {
        System.out.println();
        System.out.print("Enter ID, name or department to search: ");
        String key = in.nextLine().trim().toLowerCase();
        if (key.isEmpty()) {
            System.out.println("Please enter a search term.");
            return;
        }
        List<Student> found = new ArrayList<>();
        for (Student s : students) {
            if (String.valueOf(s.getId()).equals(key)
                    || s.getName().toLowerCase().contains(key)
                    || s.getDepartment().toLowerCase().contains(key)) {
                found.add(s);
            }
        }
        if (found.isEmpty()) {
            System.out.println("No matching students found.");
            return;
        }
        System.out.println("--- Search Results ---");
        printHeader();
        for (Student s : found) {
            printRow(s);
        }
        System.out.println(found.size() + " record(s) found.");
    }

    // ---------------------------------------------------------------
    // 4. Update student
    // ---------------------------------------------------------------
    private static void updateStudent() {
        System.out.println();
        int id = readInt("Enter ID of the student to update: ", 1, Integer.MAX_VALUE);
        Student s = findById(id);
        if (s == null) {
            System.out.println("Student with ID " + id + " not found.");
            return;
        }
        System.out.println("Current record:");
        printHeader();
        printRow(s);
        System.out.println("(Enter the new value, or press Enter to keep the old one)");

        String name = readOptionalText("Name [" + s.getName() + "]: ");
        if (!name.isEmpty()) s.setName(name);

        String dept = readOptionalText("Department [" + s.getDepartment() + "]: ");
        if (!dept.isEmpty()) s.setDepartment(dept.toUpperCase());

        Double maths = readOptionalMarks("Maths marks [" + s.getMaths() + "]: ");
        if (maths != null) s.setMaths(maths);

        Double java = readOptionalMarks("Java marks [" + s.getJava() + "]: ");
        if (java != null) s.setJava(java);

        Double db = readOptionalMarks("DBMS marks [" + s.getDb() + "]: ");
        if (db != null) s.setDb(db);

        saveStudents();
        System.out.println("Student updated successfully!");
    }

    private static String readOptionalText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = in.nextLine().trim();
            if (!line.contains("|")) return line;
            System.out.println("Field cannot contain the | character.");
        }
    }

    private static Double readOptionalMarks(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = in.nextLine().trim();
            if (line.isEmpty()) return null;
            try {
                double value = Double.parseDouble(line);
                if (value >= 0 && value <= 100) return value;
            } catch (NumberFormatException ignored) { }
            System.out.println("Invalid marks. Enter a value from 0 to 100.");
        }
    }

    // ---------------------------------------------------------------
    // 5. Delete student
    // ---------------------------------------------------------------
    private static void deleteStudent() {
        System.out.println();
        int id = readInt("Enter ID of the student to delete: ", 1, Integer.MAX_VALUE);
        Student s = findById(id);
        if (s == null) {
            System.out.println("Student with ID " + id + " not found.");
            return;
        }
        System.out.print("Delete " + s.getName() + "? (y/n): ");
        String answer = in.nextLine().trim().toLowerCase();
        if (answer.equals("y")) {
            students.remove(s);
            saveStudents();
            System.out.println("Student deleted successfully!");
        } else {
            System.out.println("Deletion cancelled.");
        }
    }

    // ---------------------------------------------------------------
    // 6. Performance report
    // ---------------------------------------------------------------
    private static void showReport() {
        System.out.println();
        if (students.isEmpty()) {
            System.out.println("No student records found.");
            return;
        }
        double total = 0;
        Student top = students.get(0);
        Student low = students.get(0);
        Map<String, Integer> grades = new TreeMap<>();
        for (Student s : students) {
            total += s.getAverage();
            if (s.getAverage() > top.getAverage()) top = s;
            if (s.getAverage() < low.getAverage()) low = s;
            grades.merge(s.getGrade(), 1, Integer::sum);
        }
        System.out.println("--- Performance Report ---");
        System.out.println("Total students : " + students.size());
        System.out.printf("Class average  : %.2f%n", total / students.size());
        System.out.printf("Topper         : %s (%.2f, Grade %s)%n",
                top.getName(), top.getAverage(), top.getGrade());
        System.out.printf("Lowest average : %s (%.2f, Grade %s)%n",
                low.getName(), low.getAverage(), low.getGrade());
        System.out.println("Grade summary  : " + grades);
    }
}
