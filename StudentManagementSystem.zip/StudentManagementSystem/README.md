# Student Management System
Java console CRUD application (JDK 8+). Records are stored in data/students.txt.

## Run
    javac StudentManagementSystem.java
    java StudentManagementSystem
